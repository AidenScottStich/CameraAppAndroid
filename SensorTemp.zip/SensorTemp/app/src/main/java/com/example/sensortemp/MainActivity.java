package com.example.sensortemp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.LightingColorFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

//    Starting with initializing some variables
    private File mPhotoFile; //this is where our file will be stored
    private ImageView mPhotoImageView; // this is the view that the image will be displayed
    private Button mSaveButton; // This is not a working part just for show

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //grabs the layout for the app

        mPhotoImageView = findViewById(R.id.photo); // this finds the element in the view that will be where the photo will display after we take it

        mSaveButton = findViewById(R.id.save_button); //this is our savebutton that will grab the element on the view

        findViewById(R.id.take_photo_button).setOnClickListener(this::takePhotoClick); // This is a event lister for the take picture button


    }

//    This method is where the image file will be store when we take the photo
    private void takePhotoClick(View view) {

        // Create the File for saving the photo
        mPhotoFile = createImageFile();

        // Create a content URI to grant camera app write permission to mPhotoFile
        Uri photoUri = FileProvider.getUriForFile(this,
                "com.example.sensortemp.fileprovider", mPhotoFile);

        // Start camera app that is on the phone
        mTakePicture.launch(photoUri);
    }

//    This is activity that will launch to take the photo and then it will see if it was launch successfully and then run the display method
    private final ActivityResultLauncher<Uri> mTakePicture = registerForActivityResult(
            new ActivityResultContracts.TakePicture(), //this is all a fast way to check if the object was created correctly
            success -> {
                if (success) {
                    displayPhoto(); // This is our display method
                }
            });

    // This is used to create the image file and it will create use a time stamp and then makes a unique name
    private File createImageFile() {
        // Create a unique image filename
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String imageFilename = "photo_" + timeStamp + ".jpg";

        // Get file path where the app can save a private image
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return new File(storageDir, imageFilename);
    }

    private void displayPhoto() {
        // This will see what the width and height of the place where the image will be placed
        int targetWidth = mPhotoImageView.getWidth();
        int targetHeight = mPhotoImageView.getHeight();

        // Get bitmap dimensions and see what the height and width of the image we took is going to be
        BitmapFactory.Options bmOptions = new BitmapFactory.Options(); // this was an object used with messing with bitmaps
        bmOptions.inJustDecodeBounds = true; // We have to set this to true to start messing with it
        BitmapFactory.decodeFile(mPhotoFile.getAbsolutePath(), bmOptions); //This decodes the photofile and this sets some varablies to hold our height and width
        int photoWidth = bmOptions.outWidth;
        int photoHeight = bmOptions.outHeight;

        // Then we take those measurements and then we will divide and see how much should be scaled down to fit our screen
        int scaleFactor = Math.min(photoWidth / targetWidth, photoHeight / targetHeight);

        // Decode the image file into a smaller bitmap that fills the ImageView
        bmOptions.inJustDecodeBounds = false; // This gets us out of the bitmap decoding and you don't want to leave that true and open
        bmOptions.inSampleSize = scaleFactor; // Then we see the size base off of our scaleFactor
        Bitmap bitmap = BitmapFactory.decodeFile(mPhotoFile.getAbsolutePath(), bmOptions); // then this will set our smaller bitmap image so it is ready for display

        // Display smaller bitmap
        mPhotoImageView.setImageBitmap(bitmap);
    }
}


